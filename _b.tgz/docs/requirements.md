# Rather Be Knee Deep — Requirements

_Living document. Director: Nicole. Last updated 2026-11-22._

This is the single record of what this app should do — shipped, agreed, and still wanted.

**How this file works.** Anything Nicole describes in a working session becomes an entry here, whether or not she frames it as a requirement. Claude writes it; Nicole edits. This file is mirrored to `docs/requirements.md` in the GitHub repo, where git versions every change. **Nicole edits the project doc copy only** — Claude propagates to the repo, so the two never disagree about who is right.

Entries are tagged: **SHIPPED** (built and live), **AGREED** (decided, not built), **PROPOSED** (raised, not decided), **DEFERRED** (consciously postponed, with a reason), **PARKED** (Nicole wants it but isn't ready to start; lives in the Parking lot below).

---

## Parking lot

Changes Nicole wants but isn't ready to make. Nothing here is a decision until she promotes it; when she does, it moves to the right section as AGREED and comes out of this list. Add with "park this: …"; review with "what's in the parking lot?". Open items here are listed in the Saturday Weekly Briefing as a reminder until they're promoted or dropped.

**P11 · "Submit your take": friends send hot takes for Nicole to review. PARKED 2026-11-21, Director's call ("log the first option in the backlog and I can pick up tomorrow").** On the resort page, an outlined "Submit your take" button between "Share this pick" and "See all picks" opens a short form: the resort pre-filled, "Your take" capped at 140 characters with a counter (the longest written take is about 120), an optional name for credit, and "Send my take". Mocked on the canvas ("Mock · Submit your take button / form"). Chosen backend, option 1: **Firestore in the `rather-be-knee-deep` Firebase project**, so the form stays on the site. Nicole's setup: turn on Firestore in the Firebase console and give the deploy service account read access. Claude's build: security rules that allow create only (no client reads), with length limits on every field; the client write; and a GitHub Actions job that exports new submissions so Claude can list them for Nicole in a session. Nothing submitted appears on the site until Nicole approves it and adds it as a take (C1). Option not taken: a Google Form plus Sheet (less setup, but the form leaves the site). _Note 2026-11-22:_ the resort page footer is now Share plus one origin-dependent link (HR-9), so the button would sit under Share.

**P12 · A navigational arrow on each pick. PARKED 2026-11-21.** Each place on Picks carries an arrow icon showing that the row opens the full resort page (the link itself shipped as P7).

**P13 · Buzz shows region chips only for regions with a subreddit. PARKED 2026-11-21.** If a region has nothing to link on Buzz, it gets no chip in the region row at the top. Follows B3, which already skips empty regions in the list. A1's shared chip row stays the same on Chase, Quiver and Picks.

**P15 · Resort badges in Quiver. PARKED 2026-11-21.** Show each resort's badge in the Quiver section, matching Chase and Picks, which already carry the badge at 44px list scale. This is the existing resort badges, not the per-ski-type stickers deferred in D9; Q5 (the ski call stays typographic) is unchanged.

Earlier items: on 2026-11-21 every item was worked through on the canvas: P1, P2 and P5–P10 were built (see *Round of 2026-11-21* below), P4 was promoted and waits on Nicole's Gemini art, and P3 was dropped at the Director's call (see C1). P14 (the desktop home button) was resolved by HR-8 on 2026-11-22 (see *Heuristic review fixes* below).

---

## The product, in one paragraph

A no-auth, link-shareable web app that recommends a North American ski destination. Four surfaces: a five-question trip planner, a forecast-driven snow chaser, a ski-type recommender for a known resort and day, and a browsable list of everywhere Nicole has skied. One self-contained HTML file, works offline, no accounts and no paywall. Live at https://rather-be-knee-deep.web.app.

---

## Foundational requirements

These came from the original brief and are non-negotiable unless Nicole changes them.

**R1 · No auth, no paywall, no install. SHIPPED.** A link that just works, on any device, first tap.

**R2 · Mobile and desktop, mobile primary. SHIPPED.** The app arrives in a text message or an Instagram DM. It works at 320px and at 200% zoom.

**R3 · Shareable via text and Instagram DM. SHIPPED.** The result encodes into the URL, so a shared link reproduces the sender's exact recommendation, badge, and reasoning. Link previews carry a share image. **Amended 2026-11-21:** a shared pick's preview shows that resort's badge (see S11). **Amended 2026-11-22:** a share link that loses its `#result=` fragment still opens that resort (HR-5).

**R4 · Nicole's ski history is browsable. SHIPPED.** 44 places, sourced from her Google Sheet, filterable. Renamed **Nicole's picks** (nav: *Picks*) 2026-10-26.

**R5 · "Nicole's Hot Take" is an explicit labelled section, not an ambient voice. SHIPPED.** The app speaks in a neutral register; her opinions sit in an attributed block. A resort with no take shows no take block — never a fabricated or placeholder one. **Amended 2026-11-22 (HR-15):** the block is attributed by its label and the N avatar; the decorative quote mark and the "— Nicole, on X" footer line are gone.

**R5a · Nicole's List is a documented exception to R5. SHIPPED 2026-08-05.** On that one surface the per-row label is gone at the Director's call — repeated 45 times it was noise, and it ate the space the verdict line needs. Attribution moved to page level instead, and is carried by three things, not one: a first-person standing line ("Hot takes from the resorts in my log book." since 2026-11-21; was "Everywhere I've skied, and what I *actually* think"), an honest coverage count (since 2026-10-26: "44 places · 9 takes written") in place of 38 per-row apologies, and a visually-hidden per-row prefix so a screen-reader user landing mid-list still hears whose opinion it is. The exception is scoped: the recommendation screen and the quiver keep the labelled, quarantined block, and `RESORTS[].hot_take.text` there still carries the whole opinion (verdict + take) as one string. Known gap: a single row screenshotted into a group chat loses the attribution, since the page header doesn't travel with it.

**R5b · A take is never truncated at runtime. SHIPPED 2026-08-05.** No ellipsis, no `line-clamp`, no `max-height`, no expand control. The previous 58-character preview was not merely tedious — it was *biased*: six of the nine written takes are structured praise-then-caveat, so a left-edge clip deleted the caveat every time, and Breckenridge's pan rendered as "For the bros. BUSY. Cute downt…", which reads as a compliment. Length is an authoring constraint enforced when the take is written — verdict 18–40 characters, take 45–95, combined ≤ 130 — never a rendering one. `verify_responsive.js` asserts this at 320px and 390px.

**R5c · The verdict is the decision; the take is the texture. SHIPPED 2026-08-05.** The two tiers only earn their space if the verdict adjudicates rather than summarises. Eight of the nine written takes already opened with the judgment, so a summarising verdict restates the sentence beneath it. The judgment moves *up* into the verdict and the take keeps only the texture. Test for a new verdict line: cover the take — if the verdict still tells you whether to go, it works; if you need the take to understand it, it is a description, rewrite it.

**R6 · Hot takes carry zero ranking weight. SHIPPED.** Commentary only. An early build rewarded resorts for merely *having* a take, which recommended Breckenridge while displaying "one of my least favourite places in CO" underneath. Removed entirely rather than replaced with a sentiment penalty.

**R7 · The recommendation carries a generated illustration. SHIPPED.** Circular sticker-style badge — heavy outline, flat saturated fills, curved type. Characters, not landscapes: a cowboy for Jackson, a cigar-smoking penguin for Vail, a marmot with a beer for A-Basin. 52 motifs across 71 resorts, no motif repeating within a region.

**R8 · Data honesty is a hard constraint. SHIPPED.** Historical averages are never presented as live forecasts. Missing data says "not published" rather than being estimated. Editorial judgments are marked as judgment. Canada has no NOAA coverage, so those resorts sit in a separate labelled tier.

**R8a · Honesty is shown with facts, not explained in paragraphs. SHIPPED 2026-10-26, Director's call.** *"Instead of explaining 'not a live forecast' simply indicate opening dates for resorts and the last time the forecast was updated."* R8 still holds in full; what changed is how it's met. A live forecast says its source and NWS's own update time ("NWS 7-day forecast · Updated 8:41 PM today"). A resort that isn't open says when it opens. The fallback still says "Not a live forecast", in one line with a retry. Longer explanations live in one closed "About this data" disclosure at the bottom of the page. See *Content-first headers* below. **Amended 2026-11-22 (HR-16/HR-17):** the fallback line is said once per page (Quiver had said it three times) and in secondary text, not bold white.

**R9 · Recommendations explain themselves in the user's own words. SHIPPED.** "You said your crew ranges from never skied to expert" beats "87% match."

**R10 · Mixed-ability groups are a first-class input. SHIPPED.** Scored as a min-max bottleneck, never an average — which correctly excludes Jackson, Alta, Kicking Horse and Revelstoke from mixed groups despite their prestige. No competitor asks this.

**R11 · Serves both newcomers and powder hounds. SHIPPED.** Beginner terrain, ski school and non-ski activities matter alongside steeps and snow quality. Neither audience is subordinate.

**R12a · The toast was intercepting taps. FIXED 2026-08-05.** The toast element sits in the DOM permanently at opacity 0, fixed just above the nav bar, and was a live pointer target the whole time. Nothing sat underneath it until Quiver Check made the splash screen taller and pushed "See everywhere Nicole's actually skied" into exactly that band, at which point that link became untappable on a 390×844 phone. `pointer-events: none` — a status message should never be a pointer target. Caught by `verify_contrast.js` failing to click the link.

**R12 · Accessible by construction. SHIPPED.** WCAG 2.1 AA. No sliders or drag anywhere. Shape and text on every status indicator, never colour alone. Reduced-motion is a first-class path, not a disable switch.

---

## Outstanding — content

**C1 · Hot takes are added as the season goes. ONGOING, Director's call 2026-11-21.** *"I don't need a 'hot take' on every resort. I can add them as the season goes on."* Not every place needs a take, so the missing ones are not a gap to close. 21 are written (12 added 2026-11-21). New ones go in the `nicoles_take_template` Google Sheet. The site does not read the sheet: say "pull the new takes" and Claude reads the sheet, drafts each new take as a verdict plus a take (R5b/R5c lengths, typos fixed, words kept), shows them for review, and ships on "ship it". The drafts live in `tools/new_takes_<date>.json`. Supersedes the earlier "write the remaining 38" target and parking-lot item P3; Crested Butte's short take can be expanded whenever Nicole likes.

**C2 · Sentiment ratings on takes. DEFERRED by Director, explicitly post-launch.** An "Overall Rating" column already exists empty in the sheet. Once populated, the app could surface how strongly Nicole rates a place. Deferred deliberately: takes are commentary, and ranking stays on the data.

**C3 · Copyedit pass on the nine written takes. AGREED.** Typos were corrected ("terrian", "familes", "advenced", "apre") at Nicole's direction; phrasing and bluntness untouched.

**C4 · Europe. DEFERRED.** Nicole's list includes Lech/Arlberg and St. Anton, excluded from v1. A deliberate future addition, not an oversight.

---

## Outstanding — design

**D1 · Two badges read tonally soft. RESOLVED by the artwork.** Bridger Bowl and Beaver Creek both now carry Gemini artwork (a lynx ski patroller; a beaver carrying fresh cookies).

**D2 · Several badges still read as ambiguous shapes. IN PROGRESS (see P4 below).** Big Sky now has artwork. Telluride and Wolf Creek are among the 43 still on vector motifs; both have new subjects waiting for art.

**D3 · Most badges are busts rather than characters mid-gesture. IN PROGRESS (see P4 below).** The 43 new subjects are each written as a moment, and the Gemini prompt now asks for the character caught mid-action.

**P4 · Finish the resort badges. AGREED 2026-11-21, waiting on Nicole's art.** 28 of 71 resorts have Gemini artwork. The other 43 have fresh subjects in `tools/badge-subjects-43.json` and the project doc `claude/Badges - remaining 43.md`: none repeats a shipped artwork, and the old duplicates (three bros, three retrievers, two foxes in beanies) are gone. Nicole generates in Gemini and saves each image as `badges-in/<resort-id>.png`; `tools/ingest_badges.py` crops to the coloured field, encodes 420px WebP and adds it with alt text. Partial batches are fine. After a batch, re-run `tools/render_og.js` so share previews pick up the new art. Check every image for real brand marks before shipping.

**D4 · Nicole's List sort-by-rating control is absent. DEFERRED (debt DD-1).** Depends on C2 — there's nothing to sort by until ratings exist.

**D5 · Chase-the-Snow reason strings are coarsely bucketed. AGREED (debt DD-2).** Several differently-scoring resorts share identical text like "Cold, light snow + terrain to match", so the ranking's gradation isn't legible in the copy. Would be noticed by exactly the data-literate powder hounds the mode serves.

**D6 · The Range Readout has never been persona-tested against Marcus. AGREED.** Genuinely novel UI with no precedent. It carries the app's main differentiator, and its motion and labelling have not been validated with the motor-impairment persona it was designed around.

**D7 · A proper `design-taste` calibration never ran. PROPOSED.** The visual direction was synthesised from Nicole's chosen direction plus her tuning note, which was specific enough to build from. A real calibration pass would sharpen it.

**D8 · New copy strings await content-writer ratification. AGREED.** The off-season screen, the sanitised dataset prose, the "show typical-season data now" escape and several badge alt-text fragments were written by the builder in the copy deck's register but never reviewed.

**D10 · Plan asks which ski pass you have. AGREED 2026-11-21, Director's call, not built.** The Plan quiz gains a pass question (Epic, Ikon, Indy, or none), built on the pass affiliations already in the resort data (kept current by T3). This makes Plan six questions instead of five. Still to decide: whether a matching pass boosts resorts in the ranking or filters to only those resorts, and how the result explains it in the user's words (R9), e.g. "You said you have an Ikon pass".

---

## Outstanding — data

**T1 · Verify the live NOAA forecast actually works. FIXED 2026-10-27.** Second root cause found on the Director's device ("Still says not a live forecast"): the grid URL carried a bogus `/forecastGridData` suffix and 404'd for every resort. Fixed to use the URL `/points` returns; verified end-to-end against the live API from GitHub Actions (58/58 grid requests OK). Test mocks now 404 the bad path, so this can't silently regress.

**T2 · `timberline-or` remains low-confidence. AGREED.** The operator publishes irreconcilable vertical-drop figures and its site 404s. Needs a direct call.

**T3 · Reconfirm pass affiliations before each season. AGREED, recurring.** Epic/Ikon/Indy rosters shift annually — 13 of 54 were wrong when first checked. Wolf Creek's Indy status specifically needs a direct call.

**T4 · Deer Valley acreage is a moving target. AGREED, recurring.** The multi-year Mayflower buildout means this needs rechecking every season, not once.

**T6 · Refresh opening dates before each season. AGREED, recurring.** `research/openings-2026-27.json` holds each resort's published 2026–27 opening day with its source, researched 2026-10-26: 45 of 71 published, 26 not yet announced, none confirmed open. Several dates came from Ikon/Vail press lists or local news because resort sites blocked fetching; conflicts are noted per row. A scheduled date flips the resort to Open on that day automatically. A slipped opening isn't modelled yet (see H5).

**T7 · Refresh day-pass prices and après lines before each season. AGREED, recurring (added 2026-11-21).** `research/day-pass-2026-27.json` (31 of 71 resorts had published 2026–27 figures on 2026-11-21; sources per row) and `research/apres.json`. Resorts that publish prices later in the season can be added any time.

**T5 · `terrain_pct` is null for 17 resorts. ACCEPTED, not a gap to close.** The matching model falls back to editorial fields rather than treating this as required input. Documented as permanent partial coverage. Since 2026-11-22 the resort page shows it as one "Terrain: Not published by the resort" row, not an empty tile (HR-15).

---

## Outstanding — infrastructure

**I1 · Custom domain. PROPOSED.** Currently `rather-be-knee-deep.web.app`. Firebase provisions and renews SSL free for a custom domain; it needs buying one and a DNS change. If it happens, update `SITE` in `build.py` so share previews point at the new domain.

**I2 · Snowriver split. PROPOSED.** Michigan's Indianhead and Blackjack merged into one resort in 2022 and are stored as one record carrying both names. Nicole chose to keep them separate; per-base-area stats are already sourced and the change is unimplemented.

---

## Content-first headers

Added 2026-10-26, Director's call: *"The app has way too much explaining at the top of each page. Don't take yourself that seriously, we aren't representing medical data… Less explaining, more letting the content tell the story. Find a pattern, test it, and deploy it."* Reference: OpenSnow's favourites list.

**N1 · Nav order by expected use. SHIPPED.** Chase · Quiver · Buzz · Plan · Picks. "Rants & Raves" became **Buzz** (the two tabs keep the names Rants and Raves); "Nicole's List" became **Nicole's picks** (nav: *Picks*). Screen-reader names start with the visible word (SC 2.5.3).

**H1 · One pattern on every surface. SHIPPED.** Title → one line of facts → compact filters → content → one closed "About this data" disclosure at the bottom. Facts, not sentences. Nothing explanatory sits above the content. `verify_content_first.js` measures it: the first resort, mountain, tab or place starts in the top third of a 390×844 screen (Picks: top half). Before → after, first content: Chase 521px → 224px, Quiver 366 → 195, Buzz 226 → 116, Picks 574 → 215.

**H2 · Opening status on every resort row. SHIPPED.** "Opens Nov 6" (announced), "Usually mid-Nov" (no announcement; typical window), "Opening TBA" (past its typical date, still unannounced). Colour marks the exception: only an opening inside the next week is coral; announced dates are strong text; estimates are quiet. When nothing is open, Chase lists what's opening soon, most forecast snow first (by opening day when there's no live forecast). **Amended 2026-11-22 (HR-17):** coral only for an opening today or tomorrow; at "inside a week" most of the Quiver list was red at once.

**H3 · Buzz keeps its provenance visible. SHIPPED.** The legal frame is unchanged in substance: the five facts stay visible under the h1 on every view, now as one line, not a ruled block. The five explained rows moved to the bottom disclosure. Cutting the visible line further was considered and rejected — it's what keeps strangers' words from reading as Nicole's.

**N2 · Bottom-nav tap targets: 56px → 66px. SHIPPED 2026-10-27, Director's call.** *"The tap targets on the bottom main nav are tight from a vertical height POV."* 56px cleared WCAG's 44px floor but not platform norms (iOS tab bar 49pt plus home indicator; Material 3, 80dp), and in mobile Safari the bottom strip sits against the browser toolbar. Now 66px: fixed parts in px, the label line in rem, so 200% zoom grows the bar to 106px rather than eating the screen. The icon sits in a 56×28 pill that fills on the current page (a non-colour "you are here", SC 1.4.1) and flashes on press. Labels 11px → 12px, icons 22px → 24px. `viewport-fit=cover` turns on `env(safe-area-inset-bottom)`, so home-screen mode clears the iPhone home indicator. `verify_nav_targets.js` measures it at 320/390/430px, light and dark, and at 200%. **Follow-up 2026-10-27 (on device):** in iOS Safari's browser mode, taps near the bottom edge are taken by Safari's toolbar, and Safari 26 gives no bottom inset in portrait (WebKit bug 306465). An iOS-only rule lifts icon and label 12px; the button still fills the bar.

**H4 · Debt from review, logged not fixed.** Buzz's filled-purple filter controls don't match the outlined chips elsewhere. Buzz has no "updated" stamp (the Reddit pipeline isn't live, so there's nothing to stamp). Plan's result card could show the resort's opening status.

**H5 · A slipped opening isn't modelled. PROPOSED.** A resort that misses its published date still flips to Open that day. Fix: an optional `delayed`/`confirmed_open` field in the openings file.

## Quiver Check

Added 2026-08-05. The 2.0 draft's third item, and the first of that list to be built. Its question is different from the other two modes': Plan a Trip asks *where should I go*, Chase the Snow asks *where is it dumping*, Quiver Check asks *I already know where and when — what do I put on my feet?*

**Q1 · Pick a resort and a day, get a ski type. SHIPPED.** Two steps, one question each, matching the trip planner's idiom. Searchable resort list grouped by state; seven-day picker; then the call.

**Q2 · Not personalised. SHIPPED, Director's call.** It does not ask what's in your quiver and does not store one. Most skiers own a general range, so the app names the ideal ski and — on every card — what to do if you don't own it. Revisit only if the un-personalised version proves too generic in use.

**Q3 · Single day, not a week-at-a-glance. SHIPPED, Director's call.** One day in, one answer out. A day-by-day strip was considered and scoped out: it would answer the question before it's asked and turn a shareable call into a dashboard. The known cost is that the mode won't tell you Thursday is the day unless you ask about Thursday.

**Q4 · Off-season behaviour matches Chase the Snow exactly. SHIPPED, Director's call. AMENDED 2026-10-26:** in the shoulder season, mountains that aren't open now list under "Opening soon" with their dates instead of disappearing behind an explainer. A mountain opening inside the 7-day forecast window can be picked, and the day picker starts on opening day. The rule itself stands: no ski call for a day the lifts aren't turning. Original entry: When nothing in the pool is realistically open, the mode does not render a picker, does not fetch, and does not recommend a ski for a mountain that isn't spinning lifts. The same per-resort shoulder-season filter applies in October and May. Consequence: the feature is invisible from roughly May to November, including right now — `verify_quiver_visual.js` exists to make it reviewable anyway.

**Q5 · No new illustration. SHIPPED, Director's call.** No sticker per ski type; the call is typographic. Deferred deliberately, not skipped — see D9 below.

**Q6 · Eight ski types, labelled in real slang. SHIPPED.** Rock Skis, Skinny Skis, Bump Sticks, The Daily Driver, Mid-Fats, The Fatties, Pow Boats, Slush Puppies — each with the industry waist-width band, a plain-English explanation of what the ski does, and a fallback line for people who don't own it. Park twin-tips appear as an aside rather than a primary call, because the park is a choice made on top of the conditions rather than instead of them.

**Q7 · The call is derived, not looked up. SHIPPED.** Forecast snowfall over the 72 hours ending on the chosen day, scaled by snow density and by how much the resort's terrain rewards float. Density comes from the real snow-to-liquid ratio — NOAA returns both snowfall and liquid-equivalent precipitation in the same response — which is what separates 12 inches of Utah blower from 12 inches of Cascade cement. Light snow demands *more* float, not less: it holds less water, so it stays unconsolidated and unsupportive. Terrain modulates the answer by at most ±25% and never drives it.

**Q8 · Shared links re-read the forecast rather than freezing an answer. SHIPPED.** `#quiver=` carries only the resort and the date. A ski call is true only as long as the forecast behind it is, so a recipient opening it tomorrow may correctly see a different answer, and a day that has passed says so plainly instead of confidently reporting last week's weather. This is deliberately different from `#result=`, which does freeze its payload — a trip-planner match doesn't decay.

**Q9 · The honesty boundary is stated on every card. SHIPPED.** It reads a weather forecast, not a snow report. It cannot see settled base depth, last night's grooming, or what's already been tracked out. When the live forecast is unreachable — or for the 10 Canadian resorts NOAA doesn't cover — the card carries the same "typical season, not a forecast" treatment used elsewhere, the reasoning switches to typical-season phrasing rather than saying "forecast", and it withholds the snow-to-liquid ratio entirely, because on that path the ratio is an assumption the app made rather than a measurement. **Amended 2026-11-22 (HR-16):** the status line says "Not a live forecast" once; the duplicate "Worth knowing" caveat is gone and the snow-report limit is one line.

### Known limits, logged

**Q10 · It cannot see backwards. ACCEPTED.** The forecast horizon starts today, so a day chosen for today or tomorrow has no observable lead-in. The card says so and tells you to size up if there's already fresh snow down. Closing this would mean adding the observations API — a second network surface, for a question the user can answer by looking out of the window.

**Q11 · Moguls are inferred, not observed. ACCEPTED.** No weather model can see a mogul field. The bump call fires on a visible dry stretch of two or more days, mid-season, at a mountain with the pitch to bump up, and the card explicitly labels itself an inference. 40 of 71 resorts qualify on the terrain test; the other 31 fall back to a groomer call.

**Q12 · 17 resorts have no `terrain_pct`. ACCEPTED (see T5).** Those resorts get the call from tags and scale alone, and are excluded from the bump inference. Killington is the notable casualty — it has one of the most famous mogul runs in the east and no published terrain breakdown in this dataset, so it reads as a groomer day.

**D9 · A sticker per ski type. DEFERRED by Director.** *"No new visuals for now, just an answer, we can get to visuals later."* Eight badges in the SummitSticker style would make the call as shareable as a resort match is. Sits behind the open badge work (P4).

---

## Demo snow — a temporary invented dataset

Added 2026-08-05, Director's call: *"Let's make a call to use an invented data set for now. You can flag it in the site UI for clarity. But that will unlock iterating on Chase the Snow and Quiver Check."*

Both forecast-driven modes read a live 7-day NOAA forecast, and from roughly May to November there is nothing to read — every resort is closed and both modes correctly render an off-season screen. That is right, and it made the two most data-heavy features impossible to iterate on for half the year. This fills the dead window.

**S1 · Invented, not last season's real numbers. SHIPPED.** Real per-day history was the preferred option and isn't reachable: NOAA's forecast API is forward-only, and the archives that do carry daily snowfall (NCEI, SNOTEL) have no egress from the build environment. So the season is generated — but generated *from* the real dataset. Each resort's invented season is scaled to sum to its own published annual snowfall, runs between its own published open and close dates, takes its temperatures from its own base elevation and latitude, and takes its snow-to-liquid ratio from its region's real character. Alta generates a deep dry season averaging 16.9:1; Mt. Baker a deeper wetter one at 9.3:1; interior BC separates from the coast range. Snowfall arrives in clustered storms with dry spells between, not as uniform daily drizzle — a model tuned against uniform noise is tuned against nothing.

**S2 · It only fills a window it cannot be wrong about. SHIPPED.** Demo data activates solely when the real calendar says the season is over — the one state in which there is no true answer to displace. It never overrides a live forecast, and it never replaces the honest typical-season fallback *during* the season: Canada's no-NOAA-coverage tier and a February NOAA outage both still behave exactly as shipped.

**S3 · It switches itself off. SHIPPED.** There is no flag to remember. Once enough of the pool is open for the season classifier to stop reporting "off-season" — around mid-November — demo mode goes false on its own and the real path takes over untouched. Verified across all twelve months.

**S4 · Nothing it generates can render unlabelled. SHIPPED.** Every value carries `isDemo: true`, a banner sits at the top of every screen, and each card carries its own badge. The banner names what is *not* affected ("Trip planning and Nicole's list are unaffected") so it can't be read as casting doubt on the planner's real data. The ski model attaches an explicit invented-data caveat to every call.

**S5 · Demo data exercises the real code path, not a degraded one. SHIPPED.** Because the generated data carries a genuine liquid-equivalent figure — unlike the typical-season fallback, whose ratio is an assumed 10:1 — demo days take the live reasoning path in full, including the measured snow-to-liquid ratio. That is the point: iterating on copy and models means running the code that actually ships.

**S6 · Dev controls. SHIPPED.** A collapsed strip on the banner sets the date (bounded to the season) and forces a condition — deep and cold, heavy and wet, dry spell, spring slush, thin early season. The two season-gated conditions move the date with them, because forcing warm temperatures in January produced a bump call rather than the slush the control named.

**S7 · Removal. AGREED.** Delete `src/demo.js` and its two tokens from `assemble.py`, or set `DEMO_ENABLED = false`. Every call site is guarded. Nothing else references it. No deadline — it disables itself in November either way.

**S8 · Side effect: the test suite is fully green again. NOTED.** `verify_contrast.js`, `verify_share_and_offline.js` and `verify_zoom_overlap.js` had all been failing since the season ended, because they navigate into Chase the Snow and assert on a ranked list that off-season correctly refuses to render. With demo data present they pass — 10/10, 14/14 and 76/76.

**S9 · One test goes the other way. NOTED 2026-08-06.** `verify_fixround.js` drops to 28/29 while demo mode is on. Its final assertion throttles `api.weather.gov` to force Chase the Snow's 4-second escalated loading state and check that the skip-ahead control appears. Demo mode short-circuits `resolveForecast` *before* any network call, so there is no wait to escalate and no skip button — the test asserts a behaviour that correctly cannot occur while demo data is active. It passes again the moment demo mode switches itself off in November. Not fixed, because the alternative is making the demo path do a pointless network round-trip.

**S10 · Two verify scripts have been pointing at a path that does not exist. NOTED 2026-08-06.** `verify_dom_prose_sweep.js` and `verify_focus_entry.js` both load `build/rather-be-knee-deep.html`; the bundle has lived at the repo root since the build was reorganised, so both have been failing with `ERR_FILE_NOT_FOUND` rather than actually testing anything. Predates the demo work. One-line fix in each, not yet applied.

**R12b · The demo banner was occluding taps beneath it. FIXED 2026-08-05.** Built as a sticky bar, which overlays whatever scrolls under it — and with the controls panel open it is roughly 500px tall, swallowing taps on the resort picker below. Now in normal flow. Second instance of this defect class in two days (see R12a); `verify_demo.js` now asserts directly that the banner occludes no interactive element beneath it.

---

## Explicitly out of scope

Booking, live pricing, or inventory. Accounts, saved trips, or cross-session personalisation. Backcountry, cat-skiing and heli operations. International resorts in the recommender.

---

## How work gets done

**Lane 1 — a specific known change.** No agents. Claude edits the source, runs the test suite, writes the files to Nicole's Mac; she commits and pushes. Minutes.

**Lane 2 — something feels wrong but isn't diagnosed.** The `design-review` skill runs the critic, accessibility reviewer and heuristic evaluator in parallel against what exists, reconciles the findings, and returns one prioritised fix list. No discovery, no re-litigating strategy.

**Lane 3 — a net-new feature.** The full pipeline, but with discovery scoped to just the new thing, since personas, principles, the visual system, tokens, badges and the copy register already exist.

**Reviewing on the canvas. Added 2026-11-21.** The Design canvas "Rather Be Knee Deep" holds artboards of Home, Chase, Picks, Buzz and a resort page, converted from the real build rather than redrawn. Nicole comments on any spot and sends it to Claude; Claude makes the change in code, tests it, re-captures the screen and replies in the thread. Picks shows only its first 8,000px (the canvas's frame limit). The canvas doesn't run the app.

Deploy is the same in all three: commit and push in GitHub Desktop, GitHub Actions rebuilds and deploys, live in about 90 seconds.

---

## Round of 2026-11-07 (branch `claude/buzz-subreddit-directory`)

**B1 · Buzz is a subreddit directory, not a feed. SHIPPED on branch, Director's call.** Rants & Raves needed a Reddit Data API pipeline that was never built, and Reddit now requires explicit approval for that access. Buzz now lists plain links to public subreddits, by region, then resort, then general. Nothing is read from Reddit. A resort with no verified subreddit is left off rather than linked to a guess (amended 2026-11-21, see B3); town subreddits stand in only where the town is the ski destination, labelled "the town's". Evidence per row: `research/resort-links.json`. Old `#rants=` links land on Buzz. Supersedes the Rants & Raves entries and their open items (takedown route, pipeline, floor figure).

**B2 · Resort result screen links out. SHIPPED on branch.** A Links block with the official site and the resort's subreddit, falling back to the region's subreddit, then r/skiing, each labelled so it isn't mistaken for the resort's own.

**A1 · One region picker across the app. SHIPPED on branch, Director's call.** Chase, Quiver, Buzz and Picks use the same scrolling chip row and the same ten areas (`src/regions.js`), "All regions" first, in a fixed geographic order. Quiver groups its list by area and shows the state on each row. Chase's old "Near" select was a home-metro re-ranker that looked like a region filter. It was briefly kept as "Traveling from", then removed at the Director's call: the region chips answer "what can I get to", and only Plan asks where you're coming from. The Beginner-friendly toggle is removed; day-trip hills stay out of Chase. **Amended 2026-11-22 (HR-21):** the row stays one scrolling line on desktop too (a mouse wheel scrolls it), instead of wrapping to three rows.

**H6 · One page header. SHIPPED on branch, Director's call.** *"Page titles should match bottom nav… every word should earn its spot."* Every tab page: h1 = the nav word exactly (Chase, Quiver, Buzz, Plan, Picks), one line saying what to do, then a status line only when needed, then controls. Splash cards and back links use the same words. Counts were cut ("44 places · 9 takes written", "29 subreddits", "4 open", "Step 1 of 2"). Plan gained its h1 and intro; its in-card step counter stays, the progress dot is gone. Chase status is "NWS forecast · Updated …" live, "Not a live forecast · Try again" otherwise (R8a still met). Picks' intro has no gold rule (removed at the Director's call; the first person does the work). Allowed deviation: drill-down screens (result, Quiver call) use the resort as their heading. **Amended 2026-11-22 (HR-27, Director approved the review):** the intro line is cut where it repeated the Home tile word for word — Chase and Plan have none; Buzz reads "Subreddits by region."; Quiver "Pick a resort and a day."; Picks keeps its first-person line. Plan's visible "Step n of 5" text is gone; the bar and its screen-reader text stay.

**R5a amended 2026-11-07.** The coverage count is gone at the Director's call. Page-level attribution on Picks is now carried by the first-person intro line alone plus the visually-hidden per-row prefix.

**H7 · New home page. SHIPPED on branch, Director's call (option A of three from a competitive audit and design exploration).** The app's own sticker (new: the app-icon mountain as a wry character, goggles up, knee deep in powder, `BRAND_STICKER_SVG` in `src/icons.js`), the headline "Where should we ski?", then one tile per section in the same style: Chase, Quiver, Buzz, Picks, and Plan last at full width so no tile reads as the one main action. Picks finally has a tile. The bottom nav now shows on home too, with nothing marked current. Options considered and not taken: a sticker wall (browse-first, no clear start) and a "this week's call" editorial card (needs weekly upkeep and a reliable live forecast; a candidate to add later). **Amended 2026-11-22 (HR-12):** Plan is now the first tile, full width, filled in the brand colour, as the one primary action; it answers the headline's question for a newcomer or a friend who was just sent a pick.

---

## Round of 2026-11-21 (branch `claude/chase-no-rank-numbers`, built on the canvas)

All committed on Nicole's Mac and passing the full suite; live once the branch is pushed and merged.

**P5 · Chase has no rank numbers. BUILT, Director's call.** The list markers and the number pill on each badge are gone, in both the open list and the typical-season list. The order already carries the ranking; it's still an `<ol>`, so screen readers keep the order.

**P10 · "The numbers" are top-aligned and uncaptioned. BUILT, Director's call.** Stat tiles align to the top. "Top to bottom, in one run" and "A typical season, not this week" are removed; "not published" captions stay.

**P6 · The resort page ends in one action. BUILT, Director's call.** One "Share this resort" button and a "See all →" link to Picks. The explainer line and "Make your own pick" are gone. Known cost: a cold-landed shared link now has "See all" as its only way into the app. **Amended 2026-11-22 (HR-8/HR-9):** the page now carries the main nav, so the known cost is gone. Share is still the one primary action; the link under it depends on how you arrived — "Find yours →" (Plan) on a shared link, "Change an answer" on your own Plan result, nothing from Chase or Picks.

**Brand line removed from the resort card. BUILT, Director's call.** The "Rather Be Knee Deep" attribution row at the top of the card is gone. It existed so a screenshot of the card still said where it came from; the share preview (S11) now carries that job for links.

**P7 · Picks open the resort page, with badges. BUILT, Director's call.** Each place shows its badge at the same 44px list scale Chase uses and opens that resort's full page, with the same published-facts reason set as a Chase row. "Back to Picks" returns to the same row. All 44 places have a resort record. Reached from Picks, the page has no "Your pick" label (Director's call): "Back to Picks" already says where you came from, and "Nicole's pick" would read as an endorsement of places she pans.

**P8 · Day pass as a price range. BUILT, Director's call.** The Cost tile becomes "Day pass": adult one-day tickets for 2026–27, cheapest published price (often online, in advance, or a set weekday deal) to the peak window rate, e.g. Big Sky "$84–$289". "Up to $X" where only a peak is published; CA$ for Canadian resorts. 31 of 71 resorts had 2026–27 figures on 2026-11-21; the rest keep the editorial cost tier, labelled Cost, rather than a guess or last season's price (R8). Sources per row in `research/day-pass-2026-27.json` (see T7).

**P9 · Après line on resort pages. BUILT, Director's call.** One line per resort, above "Off the mountain", on all 71: the type of scene plus a long-standing spot where there's an obvious one. Not labelled editorial, at the Director's call. Lesser-known hills were checked against current sources; where a bar couldn't be confirmed, the line says food in the chalet. Text in `research/apres.json`.

**P2 / B3 · Buzz lists only what it can link. BUILT, Director's call.** *"No need to over explain exclusions."* The "No subreddit of its own" lists and the About note explaining them are removed. Resorts without a subreddit are simply left off; a region with nothing to link is skipped.

**P1 · Favicon and app icons from the brand sticker. BUILT, Director's call.** Browser tab: a round crop of the sticker's face and goggles, which still reads at 32px. Home-screen and install icons: the full sticker on the dark ground, inside the maskable safe zone. The manifest's colours now match the always-dark theme.

**S11 · Shared picks preview with the resort's badge. BUILT, Director's call.** *"When these are shared, ensure the resort badge is the image that is seen in the text summary."* "Share this resort" links to `/r/<id>#result=…`. Link crawlers don't run JavaScript or see the hash, so `build.py` writes a small static page per resort carrying its own `og:image` — the badge on the dark ground at 1200×630 (`public/og/<id>.jpg`, rendered by `tools/render_og.js`). A person who taps the link goes straight on to the app with the hash intact. Verified end to end against an emulation of Firebase's cleanUrls and rewrite. Old `/#result=` links still work, with the generic preview. Re-render after badge art changes (P4).

---

## Round of 2026-11-21, evening (canvas comments; PRs #11–#15 shipped)

**Copy.** Picks intro: "Hot takes from the resorts in my log book." (R5a's first-person line). Buzz intro: "Catch up on the resort Reddit chatter." (since 2026-11-22: "Subreddits by region."). Resort page: "Share this pick" and "See all picks →" (since 2026-11-22: see P6). Terrain tiles read "Beginner", "Intermediate", "Advanced & expert" (no "terrain"). "The numbers" heading removed from the resort page and the Quiver result (PR #13).

**Quiver search below the region chips. SHIPPED, Director's call.** Region chips first, then the search box.

**H8 · Home button. SHIPPED, Director's call ("works for now").** Shared links land deep in the app, so every section page (Chase, Quiver, Buzz, Plan, Picks) and the resort page carry the home sticker as a 44px round button, top-right, beside the h1 or the back link. It goes to the home screen; screen readers hear "Rather Be Knee Deep home". No wordmark, in keeping with the brand line's removal from the resort card. **Amended 2026-11-22 (HR-8):** with the nav on every page, the sticker is gone from the section pages. It stays top-right on the resort page on phones, and on desktop sits at the leading edge of the top nav (resolves P14).

**Picks: 12 new hot takes. SHIPPED (PR #15).** Alyeska, Mt. Baker, Mount Hood (Timberline), Whistler, Bridger Bowl, Red Lodge, Jackson Hole, Park City, Snowbird, Solitude, Alta and Vail, from the sheet, approved as drafted.

**Canvas.** Quiver now has a board. The canvas also holds the home-button option boards and the P11 mockups.

---

## Heuristic review fixes, 2026-11-22 (branch `claude/heuristic-review-fixes`)

From the overnight review in the project doc `claude/Heuristic review 2026-11-21.md`. Director's call: *"I trust the team's recommendation here. Run all the recommended fixes."* Built in the cloud, full suite green, plus `verify_review_fixes.js` (49 checks) holding every item below in place. Live once the PR is merged.

**Navigation**

**HR-1 · Back works. BUILT.** Every route change and each forward step in Quiver adds a history entry, and a `popstate` handler restores it, so the browser's Back and a phone's back swipe move through the app instead of leaving it. Hash writes still use `replaceState`. In-app Back controls use `history.back()` only when this visit put a page behind them; a cold-landed link keeps its explicit fallback.

**HR-8 · The resort page carries the nav. BUILT.** On every origin, cold-landed links included. It marks the section that opened it as current. The home sticker is off the section pages (see H8).

**HR-9 · The resort page footer depends on how you arrived. BUILT.** See P6.

**HR-10 · "Your pick" only on a Plan result. BUILT.** From Chase or Picks, no eyebrow and Share reads "Share". A cold-landed link keeps "Their pick" and "Share this pick".

**HR-11 · Back lands on the row you opened. BUILT.** Chase now does what Picks did: scroll to the row and put focus on it. Picks now moves focus to the row too, not just scroll.

**HR-12 · Plan is the primary tile on Home. BUILT.** See H7.

**HR-3 · Plan keeps your step. BUILT.** Re-tapping Plan, or leaving and coming back, resumes where you were while answers exist. "Start over" clears them, and shows on the last step only.

**HR-5 · Share links without their fragment still work. BUILT.** A `/r/<id>` page with no `#result=` forwards to `#resort=<id>`, which opens that resort with its published facts.

**Simplification**

**HR-14 · Picks uses a compact stacked row at every width. BUILT.** Badge and name, then the verdict, the take and the tags on one muted line. No Region column (the chips filter by it), no "Best for" label. Fixes HR-2, desktop names running under the verdicts. Still a real table for screen readers.

**HR-15 · Resort page. BUILT.** No crowd bullet (the Crowds row says it) and no annual-average bullet (the snowfall tile says it). The empty Terrain mix tile is a one-line "Terrain: Not published" row. Nicole's hot take sits right under the stats instead of ~1,300px down. "Why this one" and "Links" headings are screen-reader only. "Not much beyond skiing — plan for that" is now "Not much beyond skiing".

**HR-16 · Quiver call. BUILT.** "Not a live forecast" once. No "The call" eyebrow or visible "Why" heading; the snow-report limit is one line; "Check a different mountain" is gone (Back to Quiver does it). The resort's state isn't repeated under its own region heading, and day chips read "Nov 22".

**HR-17 · One accent per Chase row. BUILT.** Gold "Nicole's take" is the only row accent; the orange "Crowded on powder days" flag is off the row. The fallback status line is secondary text. Coral opening dates for today or tomorrow only (see H2).

**HR-18 · Buzz. BUILT.** Region headings are the small group label used on Chase and Quiver, hidden when that region's chip is selected. No blurbs, no "Resorts" subhead; region and resort subreddits in one list; rows in regular weight with the accent on the link icon. About is one line.

**HR-19 · One footer title. BUILT.** "About this data" on every surface.

**HR-20 · Plan. BUILT.** No intro, no "Step n of 5" text, answers at most two across on desktop.

**HR-25 · Chase's number is labelled. BUILT.** "7-day" under a live total, "avg week" under a typical one.

**HR-26 · Share at the top too. BUILT.** An icon button beside the back link on the resort page and the Quiver call.

**HR-27 · Copy cuts. BUILT.** As listed in the review's table, including Chase's About trimmed from six paragraphs to two sentences.

**Desktop**

**HR-21 · One chip row. BUILT.** See A1.

**HR-22 · Resort page width. BUILT (minimal option).** Same width as every other page, with the four stats kept 2×2 so prices and units don't wrap. On desktop the page's own home sticker hides, since the top nav has one.

**Accessibility and bugs**

**HR-4 · Coral contrast. FIXED.** The dark-mode override was keyed on a `data-theme` attribute nothing set, so "Opens Nov 25" showed at 2.84:1. Now ~5:1.

**HR-6 · Page titles. FIXED.** Plan sets its own; only a Plan result is "your ski trip match".

**HR-7 · Small targets and reflow. FIXED.** Plan's Back is 44×44. No sideways scroll on Quiver or Plan at 200% text on a 320px phone.

**Not done, by the review's own recommendation**

**HR-13 · Rename the Picks nav. PROPOSED.** "Pick" means fewer things now that HR-10 shipped; left as is.

**HR-23 · Master-detail layout on desktop. PROPOSED.** Only worth it if desktop use turns out to be real.

**HR-24 · Quiver defaults the day. PROPOSED.** Would make Q1's two steps one; needs a Director's call against Q1/Q3.
