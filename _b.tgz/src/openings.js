// ---------------------------------------------------------------------------
// Opening days, 2026–27. Researched 2026-10-26 from each resort's own site or
// press coverage. One source of truth for "is it open?" across Chase and
// Quiver, replacing the per-page "not every resort is open yet" explainer
// with the fact itself: Open, or Opens Nov 20.
//
// status:
//   "opened"    — confirmed open for the season on `date`.
//   "scheduled" — a published target date. Once it passes, the resort is
//                 treated as open. Resorts do slip a day or a week; the
//                 bottom-of-page "About this data" says so once, rather than
//                 every row hedging.
//   unknown     — no published date (entry absent or date null). Falls back
//                 to the dataset's typical window ("Usually mid-Nov") and to
//                 seasonFraction() for the open/closed call.
//
// Refresh before each season (alongside requirements T3).
// ---------------------------------------------------------------------------

const OPENINGS_SEASON = "2026-27";
const OPENINGS_CHECKED = "Oct 26, 2026";
const OPENINGS = /*__OPENINGS_JSON__*/{};

function parseIsoDay(iso) {
  const [y, m, d] = String(iso).split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d, 0, 0, 0);
}

function shortDate(date) {
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/**
 * { open, label, date, known } for a resort right now.
 *   label: "Open" | "Opens Nov 20" | "Usually mid-Nov"
 * `open` drives filtering; `label` is the only copy the UI prints.
 */
function resortOpening(resort, now) {
  now = now || appNow();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const entry = OPENINGS[resort.id];
  const date = entry && entry.date ? parseIsoDay(entry.date) : null;
  if (date) {
    if (date <= today) return { open: true, label: "Open", date, known: true };
    return { open: false, label: `Opens ${shortDate(date)}`, date, known: true };
  }
  const typical = typicalOpenDate(resort, now);
  if (entry) {
    // Researched this season, nothing announced. Not open — until two weeks
    // past its usual opening day, after which an unannounced resort is far
    // more likely open than closed and a stale "TBA" would be the bigger lie.
    if (typical && today.getTime() > typical.getTime() + 14 * 864e5 && seasonFraction(resort, now) >= SEASON_OPEN_FRACTION) {
      return { open: true, label: "Open", date: null, known: false };
    }
    return { open: false, label: typical && typical > today ? `Usually ${typicalPhrase(resort)}` : "Opening TBA", date: null, known: false };
  }
  // Not in this season's research at all: the typical window decides.
  const open = seasonFraction(resort, now) >= SEASON_OPEN_FRACTION;
  if (open) return { open: true, label: "Open", date: null, known: false };
  return { open: false, label: typicalPhrase(resort) ? `Usually ${typicalPhrase(resort)}` : "Opening TBA", date: null, known: false };
}

function typicalPhrase(resort) {
  const t = String(resort.season_open || "").replace(/\s*\(.*\)\s*$/, "").trim();
  if (!t) return "";
  return t.replace(/^Mid-/, "mid-").replace(/^Early /, "early ").replace(/^Late /, "late ");
}

/** The dataset's typical opening ("Mid-Nov") as a date in the coming season. */
function typicalOpenDate(resort, now) {
  const b = parseSeasonBoundary(resort.season_open);
  if (!b) return null;
  now = now || appNow();
  // Season year: Jul–Dec belongs to the season starting this year.
  const startYear = now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1;
  return new Date(startYear + (b.month < 6 ? 1 : 0), b.month, b.day);
}

/** Sort key for not-yet-open resorts: published date first, then typical. */
function openingSortKey(resort, now) {
  const o = resortOpening(resort, now);
  if (o.date) return o.date.getTime();
  const t = typicalOpenDate(resort, now);
  return t ? t.getTime() + 1 : Number.MAX_SAFE_INTEGER; // after any same-day published date
}

/**
 * The status chip text, styled by how certain it is: an announced date reads
 * strong, a typical-window estimate reads quiet, and only an opening inside
 * the next week gets the coral accent — so colour marks the exception, not
 * every row.
 */
function openingStatusHtml(o, now) {
  now = now || appNow();
  let tone = "estimate";
  // HR-17 (heuristic review 2026-11-21): coral only for today or tomorrow.
  // At "inside a week", 6 of the first 8 Quiver rows were red at once.
  if (o.date) tone = (o.date.getTime() - now.getTime() < 2 * 864e5) ? "soon" : "announced";
  return `<span class="chase-row__status chase-row__status--${tone} body-sm">${escapeHtml(o.label)}</span>`;
}

/** "9:42 PM" today, "Yesterday 9:42 PM", or "Oct 24, 9:42 PM". */
function updatedStamp(ms, now) {
  if (!ms) return null;
  now = now || appNow();
  const d = new Date(ms);
  const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  if (sameDay(d, now)) return `${time} today`;
  const y = new Date(now); y.setDate(y.getDate() - 1);
  if (sameDay(d, y)) return `Yesterday ${time}`;
  return `${shortDate(d)}, ${time}`;
}

// ---------------------------------------------------------------------------
// Page chrome shared by every surface: a fact line under the h1, and one
// "About this data" disclosure at the bottom. The pattern is
//   title → one line of facts → content → (details, if you want them)
// Facts render as a list so a screen reader hears separate items, not a run
// of middle dots.
// ---------------------------------------------------------------------------
// The one page header, every surface (Director, 2026-11-07): the h1 is the
// bottom-nav word, exactly, and one short line says what to do here. Anything
// else (a forecast stamp, a status) follows in pageMetaHtml, only when needed.
// Home button (2026-11-21 canvas round): the home sticker, small. Since the
// heuristic review of 2026-11-21 (HR-8) every page, the resort page included,
// carries the main nav, so section pages no longer need it: it stays at the
// top-right of the resort page and at the leading edge of the desktop top nav
// (P14), and nowhere else.
function homeLinkHtml() {
  return `<a class="home-link" href="/" aria-label="Rather Be Knee Deep home"><img src="${BRAND_STICKER_ART}" alt="" width="44" height="44" decoding="async"></a>`;
}

function pageHeaderHtml(title, introHtml) {
  return `
    <header class="page-header">
      <div class="page-header__row">
        <h1 class="display-h1">${escapeHtml(title)}</h1>
      </div>
      ${introHtml ? `<p class="page-intro body-md">${introHtml}</p>` : ""}
    </header>`;
}

function pageMetaHtml(items, id) {
  const parts = items.filter(Boolean);
  if (!parts.length) return "";
  return `<ul class="page-meta body-sm" role="list"${id ? ` id="${id}"` : ""}>${parts.map((p) => `<li>${p}</li>`).join("")}</ul>`;
}

function pageAboutHtml(title, bodyHtml, id) {
  return `
    <details class="page-about"${id ? ` id="${id}"` : ""}>
      <summary class="body-sm">${escapeHtml(title)}</summary>
      <div class="page-about__body body-sm">${bodyHtml}</div>
    </details>`;
}

// ---------------------------------------------------------------------------
// Day-pass prices, 2026–27 (P8, 2026-11-21). Adult one-day lift ticket, from
// the cheapest published price (often online, in advance, or a set weekday
// deal) to the highest (usually the peak-day window rate). Researched
// 2026-11-21; sources per row in research/day-pass-2026-27.json. Resorts with
// no 2026–27 figure are absent and keep the editorial cost tier instead.
// Refresh before each season, alongside openings.
// ---------------------------------------------------------------------------
const DAY_PASS = /*__DAY_PASS_JSON__*/{};

function dayPassLabel(rid) {
  const p = DAY_PASS[rid];
  if (!p || p.high == null) return null;
  const cur = p.cur === "CAD" ? "CA$" : "$";
  if (p.single) return `${cur}${p.high}`;
  if (p.low == null) return `Up to ${cur}${p.high}`;
  return `${cur}${p.low}–$${p.high}`;
}

// Après scene (P9, 2026-11-21): one line per resort on what happens after the
// lifts close. Written 2026-11-21 in research/apres.json; venues named are
// long-standing ones. Refresh alongside openings and day-pass prices.
const APRES = /*__APRES_JSON__*/{};
