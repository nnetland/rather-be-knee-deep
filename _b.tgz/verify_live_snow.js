#!/usr/bin/env node
// ---------------------------------------------------------------------------
// verify_live_snow.js — the app reads real weather and the real calendar.
//
// Replaces verify_demo.js (removed with src/demo.js on 2026-10-25). Pins:
//   1. Nothing of demo mode survives: no DEMO global, no banner, no controls.
//   2. Late October with a handful of resorts inside their own windows shows
//      the shoulder list, fed by the live NOAA path, labelled "Live forecast".
//   3. A NOAA failure still falls back to the honest typical-season badge.
//   4. Mid-August is still the off-season screen.
//
//     node verify_live_snow.js
// ---------------------------------------------------------------------------
const { chromium } = require("playwright");
const path = require("path");

const FILE_URL = "file://" + path.resolve(__dirname, "rather-be-knee-deep.html");

let failures = 0, checks = 0;
function check(cond, msg, extra) {
  checks += 1;
  if (cond) console.log("  PASS", msg);
  else { failures += 1; console.error("  FAIL", msg, extra === undefined ? "" : JSON.stringify(extra)); }
}

function grid(fromMs) {
  const snow = [], temp = [];
  const start = new Date(fromMs); start.setUTCHours(0, 0, 0, 0);
  for (let h = 0; h < 8 * 24; h += 6) {
    const at = new Date(start.getTime() + h * 3600000).toISOString().replace(".000Z", "+00:00");
    snow.push({ validTime: `${at}/PT6H`, value: 25.4 }); // 1" per block
    temp.push({ validTime: `${at}/PT6H`, value: -6 });
  }
  return { properties: { updateTime: new Date(fromMs - 2 * 3600000).toISOString(), snowfallAmount: { values: snow }, quantitativePrecipitation: { values: snow.map((s) => ({ ...s, value: s.value / 12 })) }, temperature: { values: temp } } };
}

async function open(browser, isoNow, { noaa }) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.clock.setFixedTime(new Date(isoNow));
  await page.route("**://fonts.g**/**", (r) => r.abort());
  const hits = { n: 0, gridUrls: [] };
  if (noaa) {
    const body = JSON.stringify(grid(Date.parse(isoNow)));
    // Shaped like the real API (verified 2026-10-27): /points hands back the
    // grid URL in `forecastGridData`, and that URL has NO suffix. The old mock
    // accepted any /gridpoints/ URL, which is how a path that 404s in
    // production passed every test for months. This one 404s it too.
    await page.route("**://api.weather.gov/points/**", (r) => { hits.n++; r.fulfill({ contentType: "application/geo+json", body: JSON.stringify({ properties: { gridId: "BOU", gridX: 1, gridY: 1, timeZone: "America/Denver", forecastGridData: "https://api.weather.gov/gridpoints/BOU/1,1" } }) }); });
    await page.route("**://api.weather.gov/gridpoints/**", (r) => {
      const url = r.request().url();
      hits.gridUrls.push(url);
      if (!/\/gridpoints\/[A-Z]{3}\/\d+,\d+$/.test(url)) return r.fulfill({ status: 404, contentType: "application/problem+json", body: "{}" });
      r.fulfill({ contentType: "application/geo+json", body });
    });
  } else {
    await page.route("**://api.weather.gov/**", (r) => r.abort());
  }
  return { page, errors, hits, ctx };
}

async function run() {
  const browser = await chromium.launch();

  console.log("\n1. Demo mode is gone");
  {
    const { page, errors, ctx, hits } = await open(browser, "2026-10-25T20:00:00", { noaa: true });
    await page.goto(FILE_URL); await page.locator("#mode-chase").first().click();
    await page.waitForSelector("#freshness-badge, .center-state", { timeout: 20000 });
    check(await page.evaluate(() => typeof DEMO === "undefined" && typeof syncDemoChrome === "undefined"), "no DEMO global or demo chrome hook");
    check(await page.locator("#demo-banner").count() === 0, "no demo banner element");
    check(!(await page.content()).includes("Demo snow"), "no 'Demo snow' copy anywhere in the page");
    check(await page.evaluate(() => Math.abs(appNow().getTime() - Date.now()) < 1000), "appNow() is the real clock");

    console.log("\n2. Late October: opening dates on live data (no explainer)");
    check(await page.locator("#season-shoulder-notice").count() === 0, "no shoulder explainer paragraph");
    check(await page.locator("#chase-upcoming-h").count() === 1, "an Opening soon group renders");
    const statuses = await page.locator("#chase-body .chase-row__status").allInnerTexts();
    check(statuses.some((t) => /^Opens [A-Z][a-z]{2} \d{1,2}$/.test(t)), "rows carry published opening dates", statuses.slice(0, 4));
    check(hits.gridUrls.length > 0 && hits.gridUrls.every((u) => u === "https://api.weather.gov/gridpoints/BOU/1,1"),
      "grid requests use the URL /points returned — no /forecastGridData suffix (the production 404)", hits.gridUrls.slice(0, 2));
    const badge = (await page.locator("#freshness-badge").innerText()).trim();
    check(/NWS forecast/.test(badge) && /Updated \d{1,2}:\d{2}\s?[AP]M/.test(badge), "fact line names the source and the NWS update time", badge);
    const cards = await page.locator("#chase-body [data-rid], #chase-body .resort-card, #chase-body article").count();
    check(cards >= 1, "at least one ranked resort renders", cards);
    check(errors.length === 0, "no page errors", errors);
    await ctx.close();
  }

  console.log("\n3. NOAA unreachable: honest fallback");
  {
    const { page, ctx } = await open(browser, "2026-10-25T20:00:00", { noaa: false });
    await page.goto(FILE_URL); await page.locator("#mode-chase").first().click();
    await page.waitForSelector("#freshness-badge", { timeout: 30000 });
    const badge = (await page.locator("#freshness-badge").innerText()).trim();
    check(/Not a live forecast/.test(badge), "fallback badge says Not a live forecast", badge);
    await ctx.close();
  }

  console.log("\n4. Mid-August: still off-season");
  {
    const { page, hits, ctx } = await open(browser, "2026-08-15T20:00:00", { noaa: true });
    await page.goto(FILE_URL); await page.locator("#mode-chase").first().click();
    await page.waitForSelector(".center-state", { timeout: 20000 });
    check(await page.locator("#freshness-badge").count() === 0, "no freshness badge off-season");
    await page.waitForTimeout(500);
    check(hits.n === 0, "no NOAA request off-season", hits.n);
    await ctx.close();
  }

  await browser.close();
  console.log(`\n${checks - failures}/${checks} passed`);
  process.exit(failures ? 1 : 0);
}

run().catch((e) => { console.error(e); process.exit(1); });
